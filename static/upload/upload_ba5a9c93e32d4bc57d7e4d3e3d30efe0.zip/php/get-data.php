<?php
/* $user = 'clientApps'; */
/* $pass = 'clientApps'; */
/* $db = 'ClientApps'; */

/* $pdo = new PDO("mysql:dbname=$db;host=localhost;charset=utf8mb4", $user, $pass); */
/* $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); */
/* require "consts.php"; */
/* foreach ($Y_DATA as $y) { */
/* $stmt = $pdo->prepare("INSERT INTO chart_y(data) values (?)"); */
/* $stmt = $pdo->prepare("SELECT data FROM chart_y"); */
/* $params = []; */
/* foreach ($req->params as $v) { */
/*   if (is_string($v)) */
/*     array_push($params, $v); */
/*   else */
/*     array_push($params, json_encode($v)); */
/* } */
/* $stmt->execute($params); */
/* $stmt->execute(); */
/* } */
/* echo json_encode($stmt->fetchAll(PDO::FETCH_COLUMN)); */

function getChartData($getPK = false): array
{
  $user = 'clientApps';
  $pass = 'clientApps';
  $db = 'ClientApps';
  $out = [];

  $pdo = new PDO("mysql:dbname=$db;host=localhost;charset=utf8mb4", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

  if ($getPK === true) {
    $stmt = $pdo->prepare("SELECT id, data FROM chart_x");
    $stmt->execute();
    $out[0] = $stmt->fetchAll(PDO::FETCH_ASSOC);
  } else {
    $stmt = $pdo->prepare("SELECT data FROM chart_x");
    $stmt->execute();
    $out[0] = $stmt->fetchAll(PDO::FETCH_COLUMN);
  }

  $stmt = $pdo->prepare("SELECT data FROM chart_y");
  $stmt->execute();
  $out[1] = $stmt->fetchAll(PDO::FETCH_COLUMN);

  return $out;
}
