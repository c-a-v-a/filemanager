<?php
function toPl(string $str): string {
    return mb_convert_encoding($str, 'ISO-8859-2', 'UTF-8');
}