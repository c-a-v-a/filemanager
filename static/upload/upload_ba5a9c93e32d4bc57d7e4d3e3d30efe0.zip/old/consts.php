<?php
$WIDTH = 1200;
$HEIGHT = 300;
$IMG = imagecreatetruecolor($WIDTH, $HEIGHT);

$COLOR = new stdClass();
$COLOR->white = imagecolorallocate($IMG, 255, 255, 255);
$COLOR->red = imagecolorallocate($IMG, 255, 0, 0);
$COLOR->grey = imagecolorallocate($IMG, 255, 255, 255);
$COLOR->black = imagecolorallocate($IMG, 0, 0, 0);

$LINES = new stdClass();
$LINES->hor = new stdClass();
$LINES->hor->x1 = 0.05 * $WIDTH;
$LINES->hor->x2 = 0.95 * $WIDTH;
$LINES->ver = new stdClass();
$LINES->ver->y1 = 0.10 * $HEIGHT;
$LINES->ver->y2 = 0.80 * $HEIGHT;

$LINES->ver->x = $LINES->hor->x1;
$LINES->hor->y = $LINES->ver->y2;

$DAY_NUM = 28;
$TEMP_NUM = 6;

$HOR_SPACE = abs($LINES->hor->x1 - $LINES->hor->x2) / ($DAY_NUM - 1);
$VER_SPACE = abs($LINES->ver->y1 - $LINES->ver->y2) / $TEMP_NUM;

$FONT = 6;

$Y_DATA = [36.2, 36.4, 36.6, '.8', 37.0, 37.2];
$X_DATA = [36.4, 36.35, 36.3, 36.35, 36.4, 36.39, 36.4, 36.28, 36.4, 36.34, 36.33, 36.35, 36.21, 36.61, 36.62, 36.78, 36.71, 36.77, 36.8, 36.78, -1, 36.82, -1, 36.78, NULL, 36.82, 36.58, 36.41];
