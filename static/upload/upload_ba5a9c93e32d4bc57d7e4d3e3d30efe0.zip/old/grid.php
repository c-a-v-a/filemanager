<?php
function drawGrid(GdImage $img): void
{
  $data = [];
}
